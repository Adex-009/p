import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { db } from "@/db";
import { documents } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { putDocument } from "@/lib/storage";
import { emitWebhookEvent } from "@/lib/webhooks";
import { logAudit } from "@/lib/notifications";

export const runtime = "nodejs";
const MAX_SIZE = 10 * 1024 * 1024;
const ALLOWED_TYPES = new Set([
  "application/pdf",
  "image/png",
  "image/jpeg",
  "image/webp",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
]);
const ALLOWED_CATEGORIES = new Set(["cv", "certificate", "identification", "application_document", "business_document", "contract", "other"]);

export async function GET() {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  return NextResponse.json({ items: await db.select().from(documents).where(eq(documents.userId, session.user.id)).orderBy(desc(documents.createdAt)) });
}

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: "Sign in before uploading documents." }, { status: 401 });
  try {
    const form = await req.formData();
    const file = form.get("file");
    const categoryValue = String(form.get("category") || "other");
    if (!(file instanceof File) || file.size < 1) return NextResponse.json({ error: "Choose a file to upload." }, { status: 400 });
    if (file.size > MAX_SIZE) return NextResponse.json({ error: "Maximum file size is 10 MB." }, { status: 413 });
    if (!ALLOWED_TYPES.has(file.type)) return NextResponse.json({ error: "Unsupported file type. Upload PDF, Word or an image file." }, { status: 415 });
    if (!ALLOWED_CATEGORIES.has(categoryValue)) return NextResponse.json({ error: "Invalid document category." }, { status: 400 });
    const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 180) || "upload";
    const storagePath = `${session.user.id}/${crypto.randomUUID()}-${safeName}`;
    await putDocument(storagePath, await file.arrayBuffer(), { contentType: file.type, fileName: safeName });
    const [doc] = await db.insert(documents).values({ userId: session.user.id, category: categoryValue as "cv" | "certificate" | "identification" | "application_document" | "business_document" | "contract" | "other", fileName: safeName, fileType: file.type, fileSize: file.size, storagePath, isPrivate: true }).returning();
    await emitWebhookEvent("document.uploaded", { documentId: doc.id, category: categoryValue, fileName: doc.fileName }, { type: "document", id: doc.id });
    await logAudit({ actorId: session.user.id, action: "document.uploaded", targetType: "document", targetId: doc.id });
    return NextResponse.json({ ok: true, id: doc.id }, { status: 201 });
  } catch (error) {
    if (error instanceof Response) return error;
    return NextResponse.json({ error: "Upload failed. Check private storage configuration and try again." }, { status: 500 });
  }
}
