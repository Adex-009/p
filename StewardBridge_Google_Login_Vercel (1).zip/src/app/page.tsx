import LegacyApp from './legacy/LegacyApp';
import './legacy/legacy.css';

export default function HomePage() {
  return <LegacyApp />;
}
