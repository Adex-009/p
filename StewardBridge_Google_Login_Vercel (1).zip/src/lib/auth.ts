import NextAuth, { type NextAuthConfig } from "next-auth";
import Google from "next-auth/providers/google";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";

const providers: NextAuthConfig["providers"] = [];

const googleId = process.env.GOOGLE_CLIENT_ID;
const googleSecret = process.env.GOOGLE_CLIENT_SECRET;
if (googleId && googleSecret) {
  providers.push(
    Google({
      clientId: googleId,
      clientSecret: googleSecret,
    }),
  );
}

export const { handlers, signIn, signOut, auth } = NextAuth({
  secret: process.env.AUTH_SECRET,
  trustHost: true,
  session: { strategy: "jwt" },
  pages: {
    signIn: "/auth/sign-in",
    error: "/auth/sign-in",
  },
  providers,
  callbacks: {
    async signIn({ user, account, profile }) {
      if (account?.provider === "google" && user?.email) {
        if ((profile as { email_verified?: boolean } | undefined)?.email_verified !== true) return false;
        const email = user.email.toLowerCase().trim();
        const adminEmail = process.env.ADMIN_EMAIL?.toLowerCase().trim();
        const isAdminEmail = Boolean(adminEmail && email === adminEmail);
        const [existing] = await db.select().from(users).where(eq(users.email, email)).limit(1);
        if (existing) {
          // Promote an existing account only after Google confirms this email is verified.
          await db.update(users).set({
            name: user.name ?? existing.name,
            image: user.image ?? existing.image,
            ...(isAdminEmail ? { role: "admin" as const, isAdminAuthorized: true } : {}),
            updatedAt: new Date(),
          }).where(eq(users.id, existing.id));
        } else {
          await db.insert(users).values({
            email,
            name: user.name ?? null,
            image: user.image ?? null,
            role: isAdminEmail ? "admin" : null,
            isAdminAuthorized: isAdminEmail,
          });
        }
      }
      return true;
    },
    async jwt({ token, user, account }) {
      token.authProvider = account?.provider ?? token.authProvider;
      const email = (user?.email ?? token.email)?.toLowerCase();
      if (email) {
        const [dbUser] = await db.select().from(users).where(eq(users.email, email)).limit(1);
        if (dbUser) {
          token.uid = dbUser.id;
          token.role = dbUser.role;
          token.onboardingComplete = dbUser.onboardingComplete;
          token.isAdminAuthorized = dbUser.isAdminAuthorized;
          token.email = dbUser.email;
          token.name = dbUser.name ?? undefined;
          token.picture = dbUser.image ?? undefined;
        }
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        session.user.id = (token.uid as string) ?? "";
        session.user.role = (token.role as "candidate" | "business" | "admin" | null) ?? null;
        session.user.onboardingComplete = Boolean(token.onboardingComplete);
        session.user.isAdminAuthorized = Boolean(token.isAdminAuthorized);
        session.user.authProvider = typeof token.authProvider === "string" ? token.authProvider : "";
      }
      return session;
    },
  },
});

export const isGoogleAuthEnabled = Boolean(googleId && googleSecret);
